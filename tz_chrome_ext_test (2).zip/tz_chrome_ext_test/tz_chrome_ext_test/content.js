/*Tally Integration*/

/*Input file uplaod flow for choose button, submit button, reset button, text area buttons actions
 # Submit button click actions creating unique jsons for unique reference_number for all tally-actions.
 */


/* List of global variables*/

var file_data;
var port_number = '9000';
var tally_host = 'localhost';
var tranzact_host = "https://be.letstranzact.com/";
// var tranzact_host = "http://127.0.0.1:8001/";
// var tranzact_host = "https://staging1-appv2.letstranzact.com/";
var company_name;
var selected_document = '';
var stock_item_correct = 0;
var stock_item_ignore = 0;
var sundry_ledger_correct = 0;
var sundry_ledger_ignore = 0;
var acc_ledger_ignore = 0;
var check_stock_complete = 0;
var check_sundry_complete = 0;
var check_accounting_complete = 0;
var unique_sl_no = [];
var unique_voucher_details = [];
var organized_data_list = [];
var stock_error_list = [];
var created_stock_item = [];
var created_ledger_data = [];
var sheet_2_json;
var sheet_3_json;
var deleted_voucher_details = [];
var delete_found_udf = [];
var existing_tranzact_id_date_dict = {};
var sundry_ledger_unavailable = [];
var existing_voucher_ref = [];
var user_id;
var voucher_created_count = 0;
var voucher_failed_count = 0;
var voucher_creation_report = [];
var voucher_delete_report = [];
var journal_voucher_creation_report = [];
var final_deleted_udf = [];
var file_selected = 0;
var token;
var tally_connect = 0;
var tdl_loaded = 0;
var voucher_ignored = [];
var voucher_sl_no_ignored = [];
var unique_voucher_no_journal = [];
var unique_voucher_details_journal = [];
var organized_data_list_journal = [];
var cancelled_udf = [];
var successful_cancel_voucher = [];
var fail_cancel_voucher = [];
var existing_tally_ledgers = [];
var ledger_name_mapping = {};
var sundry_ledger_voucher_no_link = {};
var stock_voucher_no_link = {};
var accounting_ledger_voucher_no_link = {};
var default_credit_period= {};
var decimal_place = 2;
var sl_no_tranzact_id_list = {};
var tranzact_id_sl_no_link = {};
var check_tranzact_id = 1;
var success_tranzact_id_list = [];
var tranzact_id_def = {'purchase':0, 'sales':1, 'payment':2, 'receipt':3, 'stock':4, 'credit_note':5, 'debit_note':6, 'journal':7};

var input_company_name = "";
var is_tally_prime = 0;
var xml_get_voucher_details = "<ENVELOPE>" +
                                "<HEADER>" +
                                "<VERSION>1</VERSION>" +
                                "<TALLYREQUEST>Export</TALLYREQUEST>" +
                                "<TYPE>Collection</TYPE>" +
                                "<ID>Collection of Vouchers</ID>" +
                                "</HEADER>" +
                                "<BODY>" +
                                "<DESC>" +
                                "<STATICVARIABLES>" +
                                "<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>" +
                                "<VoucherTypeName>Purchase</VoucherTypeName>" +
                                "<SVCURRENTCOMPANY>company_name</SVCURRENTCOMPANY>" +
                                "<SVFROMDATE TYPE=\"DATE\">20190101</SVFROMDATE>\n" +
                                "<SVTODATE TYPE=\"DATE\">20221231</SVTODATE>\n"+
                                "</STATICVARIABLES>" +
                                "<TDL>" +
                                "<TDLMESSAGE>" +
                                "<COLLECTION NAME=\"Collection of Vouchers\" ISMODIFY=\"No\">" +
                                "<TYPE>Voucher</TYPE>" +
                                "<FETCH>REFERENCE</FETCH>" +
                                "<FETCH>PARTYNAME</FETCH>" +
                                "<FETCH>ISCANCELLED</FETCH>" +
                                "</COLLECTION>" +
                                "</TDLMESSAGE>" +
                                "</TDL>" +
                                "</DESC>" +
                                "</BODY>" +
                                "</ENVELOPE>";

$(document).ready(function (e) {

    set_default_values();
    var input_tally_company_name = localStorage.getItem('input_tally_company_name');
    $('#company_name_input').val(input_tally_company_name);

    $("#tally_prime_yes").click(function () {
        is_tally_prime = 1;
        $("#tally_version_ques").css('display', 'none');
        $("#tally_company_name_div").css('display', 'block');

    });
    $("#tally_prime_no").click(function () {
        $("#tally_prime_section").css('display', 'none');
        $("#file_dropdown_div").css('display', 'block');
        start_initial_steps();
    });
    $("#tally_prime_continue").click(function () {

        input_company_name = $('#company_name_input').val();
        if (input_company_name != "") {
            localStorage.setItem('input_tally_company_name', input_company_name);

            $("#tally_prime_section").css('display', 'none');
            $("#file_dropdown_div").css('display', 'block');

            start_initial_steps();
        } else {
            $('#company_name_input_warning').css('display', 'block');
        }
    });
});

function start_initial_steps() {

    $(".home_page input").prop("disabled", true);
    $(".home_page button").prop("disabled", true);
    $(".home_page select").prop("disabled", true);
    token = localStorage.getItem('auth_token');
    var email = localStorage.getItem('email');
    user_id = localStorage.getItem('user_id');


    $.ajax({
        "async": true,
        "crossDomain": true,
        "url": tranzact_host + "main/login/api-token-refresh/",
        // "url": "https://staging1-appv1.letstranzact.com/api-token-verify/",
        // "url": "http://127.0.0.1:8001/api-token-verify/",
        "method": "POST",
        "headers": {
            "content-type": "application/json",
            "cache-control": "no-cache",
        },
        "processData": false,
        "data": JSON.stringify({
            "token": token
        }),
        success: function () {
            $("#log_in_block").css('display', 'none');
            $("#log_out_block").css('display', 'block');
            $('#logged_in_user_id').text(email);

            $(".home_page input").prop("disabled", false);
            $(".home_page button").prop("disabled", false);
            $(".home_page select").prop("disabled", false);

            localStorage.setItem('auth_token', token);

            check_tally_server();
        },
        error: function () {
        }
    });

}

function set_default_values() {
    var check_tranzact_id_storage = localStorage.getItem('check_tranzact_id');
    var tally_host_localstorage = localStorage.getItem('tally_host');
    var port_number_localstorage = localStorage.getItem('port_number');

    if (tally_host_localstorage){
        tally_host = tally_host_localstorage;
        $('#tally_host').val(tally_host_localstorage);
    }


    if (port_number_localstorage){
        port_number = port_number_localstorage;
        $('#port_number').val(port_number_localstorage);
    }

    if (check_tranzact_id_storage == 1 || check_tranzact_id_storage == 0){
        check_tranzact_id = check_tranzact_id_storage;
        $('#check_tranzact_id').val(check_tranzact_id.toString());
        $('#check_tranzact_id').find('option[value="check_tranzact_id"]').attr('selected','selected');
    }
}











/* 3. Payment Voucher 3.1 - check _payment_creation 3.2 create_payment_voucher */




/*-----------------------------------------------------------------------------------------*/

/*Stock item creation */
$(document).ready(function () {
    $("#bulk_stock").click(function () {
        create_bulk_stock_item()
        $("#bulk_stock").html('Creating.. <i class="fas fa-circle-notch fa-spin"></i>');

    });
});


/*3.1*/
function call_it() {
    if (count == 0) {
        alert("Stock items are created");
        $("#bulk_stock").html('Created');
        $("#bulk_stock").css('display', 'none').hide("slow");
    }
}

function create_bulk_stock_item() {
    var count = 0;
    var counter = 1;

    for (var i = 0; i < sheet_1_json.length; i++) {
        count++;
        var Stock_ITEM_UOM_Format = "<ENVELOPE>\n<HEADER>\n<TALLYREQUEST>Import Data</TALLYREQUEST>\n</HEADER>\n<BODY>\n<IMPORTDATA>\n<REQUESTDESC>\n<REPORTNAME>All Masters</REPORTNAME>\n<STATICVARIABLES>\n<SVCURRENTCOMPANY>" + company_name + "</SVCURRENTCOMPANY>\n</STATICVARIABLES>\n</REQUESTDESC>\n<REQUESTDATA>\n\n<TALLYMESSAGE xmlns:UDF=\"TallyUDF\">\n<UNIT NAME=\"" + sheet_1_json[i].UOM + "\" ACTION=\"CREATE\">\n<NAME>" + sheet_1_json[i].UOM + "</NAME>\n<ISSIMPLEUNIT>Yes</ISSIMPLEUNIT>\n<FORPAYROLL>No</FORPAYROLL>\n</UNIT>\n</TALLYMESSAGE>\n\n<TALLYMESSAGE xmlns:UDF=\"TallyUDF\">\n<STOCKITEM NAME=\"" + sheet_1_json[i].Stock_Item + "\" ACTION=\"Create\">\n<GSTTYPEOFSUPPLY>Goods</GSTTYPEOFSUPPLY>\n<COSTINGMETHOD>Avg. Cost</COSTINGMETHOD>\n<VALUATIONMETHOD>Avg. Price</VALUATIONMETHOD>\n<BASEUNITS>" + sheet_1_json[i].UOM + "</BASEUNITS>\n<LANGUAGENAME.LIST>\n<NAME.LIST>\n<NAME>" + sheet_1_json[i].Stock_Item + "</NAME>\n</NAME.LIST>\n</LANGUAGENAME.LIST>\n</STOCKITEM>\n</TALLYMESSAGE> \n</REQUESTDATA>\n</IMPORTDATA>\n</BODY>\n</ENVELOPE>"
        var xhr = new XMLHttpRequest();
        xhr.withCredentials = true;
        xhr.addEventListener("readystatechange", function () {
            if (this.readyState == 4 && this.status == 200) {
                stock_item_response = this.responseText;
                // console.log(stock_item_response);
                // console.log(counter);
                count--;
                call_it()
                counter++;
            }
        });
        // xhr.open("POST", "http://" + tally_host + ":" + port_number + "/");
        // xhr.setRequestHeader("content-type", "text/xml");

        var connection_data = get_xhr(xhr, Stock_ITEM_UOM_Format);

        xhr = connection_data[0];
        var data_to_send = connection_data[1];

        xhr.send(data_to_send);
        // console.log(Stock_ITEM_UOM_Format);
    }
}












