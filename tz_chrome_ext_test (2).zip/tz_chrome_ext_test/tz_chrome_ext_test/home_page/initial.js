function parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}
window.onload = function (){
    if(localStorage.getItem('auth_token')){
        alert('Error in logging in');
        console.log("hey")
        $("#log_in_block").css('display', 'none');
            $("#log_out_block").css('display', 'block');
            $('#logged_in_user_id').text(localStorage.getItem('email'));

            $(".home_page input").prop("disabled", false);
            $(".home_page button").prop("disabled", false);
            $(".home_page select").prop("disabled", false);

            $("#logging_in_alert").css('display', 'block');
            $("#logging_in_alert").fadeTo(2000, 500).slideUp(500, function () {
                $("#logging_in_alert").slideUp(500);
            });

            check_tally_server();
    }
}
$('#edit_port').on('click', function(){
    $('#port_number').prop('readonly', false);
    $('#edit_port').prop('hidden', true);
    $('#save_port').prop('hidden', false);
    //console.log($('#save_port').prop('hidden'))

});

$('#save_port').on('click', function(){
    $('#port_number').prop('readonly', true);
    port_number = $('#port_number').val();
    $('#edit_port').prop('hidden', false);
    $('#save_port').prop('hidden', true);
    localStorage.setItem('port_number', port_number);
    check_tally_server();

});

$('#edit_host').on('click', function(){
    $('#tally_host').prop('readonly', false);
    $('#edit_host').prop('hidden', true);
    $('#save_host').prop('hidden', false);
    //console.log($('#save_port').prop('hidden'))

});

$('#save_host').on('click', function(){
    $('#tally_host').prop('readonly', true);
    tally_host = $('#tally_host').val();
    $('#edit_host').prop('hidden', false);
    $('#save_host').prop('hidden', true);
    localStorage.setItem('tally_host', tally_host);
    check_tally_server();

});


$('#check_tranzact_id').on('change', function (e) {
    check_tranzact_id = parseInt($('#check_tranzact_id').val());
    localStorage.setItem('check_tranzact_id', check_tranzact_id);

});
$('#button_login_user').on('click', function (e) {
    e.preventDefault();
    
    var email = $("#input_email_id").val()?$("#input_email_id").val():localStorage.getItem('email');
    var password = $("#input_password").val();
    $.ajax({
        "async": true,
        "crossDomain": true,
        "url": tranzact_host + "main/login/password-login/",
        // "url": "https://staging1-appv1.letstranzact.com/api-token-auth/",
        "method": "POST",
        "headers": {
            "content-type": "application/json",
            "cache-control": "no-cache",
        },

        "processData": false,
        "data": JSON.stringify({
            "email": email,
            "password": password
        }),
        success: function login(response) {
            response = response["data"];
            token = response["access_token"];
            var token_header = parseJwt(token);
            user_id = token_header['user_id'];
            company_name = token_header['company_name'];
            localStorage.setItem('auth_token', token);
            localStorage.setItem('email', email);
            localStorage.setItem('user_id', user_id);
            localStorage.setItem('company_name',company_name);
            $("#log_in_block").css('display', 'none');
            $("#log_out_block").css('display', 'block');
            $('#logged_in_user_id').text(email);
       
            $(".home_page input").prop("disabled", false);
            $(".home_page button").prop("disabled", false);
            $(".home_page select").prop("disabled", false);
            
            $("#logging_in_alert").css('display', 'block');
            $("#logging_in_alert").fadeTo(2000, 500).slideUp(500, function () {
                $("#logging_in_alert").slideUp(500);
            });
            
            check_tally_server();
            alert('Error in logging in');
            // console.log(localStorage);
        },

        error: function (err) {
            alert('Error in logging in');
            console.log(err);
            // location.reload();
        }
    });
});


$('#button_logout_user').on('click', function (e) {
    e.preventDefault();
    localStorage.clear();
    location.reload();
});


$('.btn_choose_file').on('click', function () {
    $('#input_file').trigger('click');
});


$('#input_file').on('change', function (e) {
    var file = e.target.files[0];
    $('#input_choose_file').val(file.name);

    readFile(file, function (e) {
        file_data = e.target.result;
    });

    function readFile(file, onLoadCallback) {
        var reader = new FileReader();
        reader.onload = onLoadCallback;
        reader.readAsBinaryString(file);
    }

    file_selected = 1;
});


/*checking tally server is running and selected company name */
function check_tally_server() {

    if (tally_host == 'localhost'){
        check_tally_open();
    }else{
        $.ajax({
        "async": true,
        "crossDomain": true,
        "url": tranzact_host + "integration/tally-extension/check-ip/",
        "method": "POST",
        "headers": {
            "content-type": "application/json",
            "Authorization": "Bearer " + token,
            "cache-control": "no-cache",
        },
        "processData": false,
        "data": JSON.stringify({
            "tally_ip": tally_host,
            "user_id": user_id
        }),
        success: function (data) {

            if(data['data']['status'] == 'success'){
                console.log("tally ip check success");
                check_tally_open();
            }else{
                alert('Incorrect Tally IP Address');
            }

        },
        error: function () {
        }
    });
    }

}


function check_tally_open() {
    if (is_tally_prime == 1) {
        check_tally_open_prime();
    } else{
        check_tally_open_old();
    }
}
function get_xhr(xhr, data) {
    xhr.open("POST", "http://" + tally_host + ":" + port_number + "/");
    xhr.setRequestHeader("content-type", "text/xml");
    var preparedData = data;
    return [xhr, preparedData];
}

function check_tally_open_old() {

    var data = "<ENVELOPE>  \n<HEADER>\n<TALLYREQUEST>Export Data</TALLYREQUEST>  \n</HEADER> \n<BODY>    \n<EXPORTDATA>      \n<REQUESTDESC>        \n<REPORTNAME>List of Accounts</REPORTNAME>        \n<STATICVARIABLES>          \n<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>          \n<ACCOUNTTYPE>Company</ACCOUNTTYPE>        \n</STATICVARIABLES>      \n</REQUESTDESC>    \n</EXPORTDATA>  \n</BODY>\n</ENVELOPE>\n";
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    // xhr.open("POST", "http://" + tally_host + ":" + port_number + "/");
    // xhr.setRequestHeader("content-type", "text/xml");

    var connection_data = get_xhr(xhr, data);

    xhr = connection_data[0];
    var data_to_send = connection_data[1];

    xhr.send(data_to_send);
    // console.log(data);a
    // console.log(xhr);
    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4 && this.status == 200) {
            // console.log("here")
            var str_response = this.responseText;
            var company_attr1 = str_response.indexOf("<SVCURRENTCOMPANY>");
            var company_attr2 = str_response.indexOf("</SVCURRENTCOMPANY>");
            company_name = str_response.slice(company_attr1, company_attr2);
            var user_company = localStorage.getItem('company_name');
            company_name = company_name.replace("<SVCURRENTCOMPANY>", "").trim();
            // console.log(company_name);
            $("#tally_alert").css('display', 'block');
            $("#tally_alert_company_name").text(tally_char_correction_get_original(company_name));
            $("#user_company_name").text(tally_char_correction_get_original(user_company));
            $("#tally_failure_alert_msg").css('display', 'none');
            $("#tally_success_alert_msg").css('display', 'block');
            if (user_company == tally_char_correction_get_original(company_name)){
                $("#tally_company_mismatch_msg").css('display', 'none');
                tally_connect = 1;
            }
            else{
                $("#tally_company_mismatch_msg").css('display', 'block');
                tally_connect = 0;
            }
            enable_check_button();
            check_tdl_loaded();
        }
        else if (this.readyState === 4 && this.status == 0 || this.readyState === 4 && this.status == 403) {
            // console.log("xxx");
            // console.log(this.readyState);
            // console.log(this.status);
            $("#tally_alert").removeClass('alert-dark').addClass('alert-danger');
            $("#tally_alert").css('display', 'block');
            $("#tally_failure_alert_msg").css('display', 'block');
            $("#tally_success_alert_msg").css('display', 'none');
            tally_connect = 0;
        }
    });
    enable_check_button();
}

function check_tally_open_prime() {

    
    company_name = tally_char_correction(input_company_name);
    var user_company = localStorage.getItem('company_name');
    
    // console.log(company_name);
    $("#tally_alert").css('display', 'block');
    $("#tally_alert_company_name").text(tally_char_correction_get_original(company_name));
    $("#user_company_name").text(tally_char_correction_get_original(user_company));
    $("#tally_failure_alert_msg").css('display', 'none');
    $("#tally_success_alert_msg").css('display', 'block');
    if (user_company == tally_char_correction_get_original(company_name)){
        $("#tally_company_mismatch_msg").css('display', 'none');
        tally_connect = 1;
    }
    else{
        $("#tally_company_mismatch_msg").css('display', 'block');
        tally_connect = 0;
    }
    
    check_tdl_loaded();

    enable_check_button();
}


function check_tdl_loaded() {

    if (check_tranzact_id == 0) {
        tdl_loaded = 1;
        return
    }

    xml_get_voucher_details = xml_get_voucher_details.replace('company_name', company_name);
    var voucher_response = '';

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            voucher_response = this.responseText;

            voucher_response = xhr.responseText;
            // voucher_response = voucher_response.replace(/UDF:/g, "UDF")

            voucher_response = clean_text_for_xml(voucher_response);

            // console.log(voucher_response);

            var xmlDoc = $.parseXML(voucher_response);
            $xml = $( xmlDoc );
            var voucher = $("VOUCHER", xmlDoc);

            var BreakException= {};

            try {
                $.each(voucher, function () {

                var tranzact_id = $(this).find("UDFTRANZACTVALUE").first().text();

                if (tranzact_id !== "") {
                    tdl_loaded = 1;
                    throw BreakException;
                }
            });
                
            } catch (e) {
                if (e !== BreakException){
                    throw e;
                }
            }


            if (tdl_loaded == 0){
                $("#tally_tdl_not_loaded_msg").css('display', 'block');
            }else{
                $("#tally_tdl_not_loaded_msg").css('display', 'none');
            }

            enable_check_button();

        }
    });

    // xhr.open("POST", "http://" + tally_host + ":" + port_number + "/");
    // xhr.setRequestHeader("content-type", "text/xml");

    var connection_data = get_xhr(xhr, xml_get_voucher_details);

    xhr = connection_data[0];
    var data_to_send = connection_data[1];

    xhr.send(data_to_send);
}


function disable_operation(id){
    $('#'+id).prop('disabled', true);
};
function enable_operation(id){
    $('#'+id).prop('disabled', false);
};
function enable_check_button(){
    if (port_number != '' && selected_document != '' && file_selected == 1 && tally_connect == 1 && tdl_loaded == 1){
        enable_operation('button_check');
    }else{
        console.log("hello")
        disable_operation('button_check');
    }
}


$("#synch_tally").click(function () {
    check_tally_server();
    return false;
});

$('#confirm_company').on('click', function () {
   tally_connect = 1;
   $("#tally_company_mismatch_msg").css('display', 'none');
});


$('#confirm_tdl').on('click', function () {
   tdl_loaded = 1;
   $("#tally_tdl_not_loaded_msg").css('display', 'none');
   enable_check_button();
});
